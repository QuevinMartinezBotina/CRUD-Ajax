<?php

define('PATH_APP', './app/');
define('PATH_CONFIG', './config/');
define('PATH_SRC', './src/');
define('PATH_ROUTES', './routes/');
define('PATH_CONTROLLERS', './app/http/controllers/');
define('PATH_VIEWS', './resources/views/');
