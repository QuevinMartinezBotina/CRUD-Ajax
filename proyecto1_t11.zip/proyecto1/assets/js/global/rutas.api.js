var RUTAS_API = {
    USUARIOS: {
        LISTAR: 'listar_usuarios',
        REGISTRAR_USUARIO: 'usuarios/registrar',
    }
};