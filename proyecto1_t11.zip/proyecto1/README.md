# Proyecto 1 - Crud MVC con PHP Ajax y MySQL
Tutoriales del proyecto: https://www.youtube.com/watch?v=oBRVJmN3hvA&list=PLHrm50e5CR92HOIk4ZUH5JyL0AsyeB0dd

En este proyecto encontraremos un crud con Ajax, PHP y MySQL, en este se podrá observar un ejemplo básico de como listar, insertar, actualizar y eliminar registros con ajax, php y mysql. Además podermos observar como se realiza una conexión PDO, un controlador de persistencia para la base de datos genérico y un ejemplo básico para observar como funciona un controlador de rutas o Routing en php.
