<?php

require_once './src/launcher.php';
