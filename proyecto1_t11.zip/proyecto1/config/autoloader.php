<?php

return [
    PATH_APP,
    PATH_SRC
];
